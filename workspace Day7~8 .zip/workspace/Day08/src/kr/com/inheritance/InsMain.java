package kr.com.inheritance;

import kr.com.obj.Student;

/**
 * call by reference 와
 * call by value.
 * 
 * static 예제
 * @author PC
 *
 */
public class InsMain {
	/**
	 * 정적 메서드 선언
	 * static 을 붙이면 정적 메서드 또는 변수가 된다.
	 * static 메서드 또는 변수는 클래스가 컴파일 된는 시점에서
	 * 메모리에 올라가기 때문에
	 * 클래스의 객체화 전에 사용가능하다.
	 * @param sp
	 */
	
	public static void modifyStudent(Students sp) {
		int age = sp.getAge() + 1;
		sp.setAge(age);
		System.out.println("함수호출 학생 나이 : " + sp.getAge());
	}
	
	public static void addValue(int value) {
		value = value + 1;
		System.out.println("함수호출 :" + value);
	}

	public static void main(String[] args) {
		
		int num = 10;
		Students sp = new Students("홍길동", "남자", 100, "졸업반", 90, 90, 90);
		
		InsMain.addValue(num);
		System.out.println("함수 호출 후 : " + num);
		
		InsMain.modifyStudent(sp);
		System.out.println("함수호출 후 학생 나이 : " + sp.getAge());
		
		//참조형 변수는 파라미터에 값을 채울 때 주소를 던지기 때문에 파라미터의 값을 변경하면 원본의 값도 변한다. 이는 call by reference하고 한다.
		
		
		
	}

}
