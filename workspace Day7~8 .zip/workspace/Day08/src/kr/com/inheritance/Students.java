package kr.com.inheritance;

//사람을 상속받음
public class Students extends Person{
	
	private String grade;
	private int kor;
	private int eng;
	private int math;
	
	public Students(String name, String gender, int age, String grade, int kor, int eng, int math) {
		super(name, gender, age);//super는 상위 클래스의 생성자 
		
		this.setGrade(grade);
		this.setKor(kor);
		this.setEng(eng);
		this.setMath(math);	
	}
	
	
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	
	

}
