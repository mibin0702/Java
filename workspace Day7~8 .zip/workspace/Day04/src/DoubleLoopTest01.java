/**
 * 이중for문을 이용한 
 * 간단한 구구단 만들기
 * @author PC
 *
 */
public class DoubleLoopTest01 {

	public static void main(String[] args) {

		for(int i = 2; i < 10; i++) {
			for(int j = 1; j<10; j++) {
				System.out.print(i + "X" + j + "= " + (i*j) + "\t");
			}
			System.out.println(); //System.out.println()는 출력에도 사용되지만 줄바꿈에도 사용한다.
		}
		
		//변형문제
		//단 방향 바꾸기
		for(int i = 1; i < 10; i++) {
			for(int j = 2; j<10; j++) {
				System.out.print(j + "X" + i + "= " + (i*j) + "\t");
			}
			System.out.println();
		}
		
		//선생님 답
		 for(int i = 2; i < 10; i++) {
			for(int j = 1; j<10; j++) {
				System.out.print(j + "X" + i + "= " + (i*j) + "\t");
			}
			System.out.println();
		 }
		 

	}
}
