/**
 * 별찍기1= 직각삼각형
 * @author PC
 *
 */
public class DoubleLoopTest02 {

	public static void main(String[] args) {

		for(int i =0; i < 10; i++) {
			for(int j = 0; j < (i+1) ; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		//줄띄고...
		System.out.println();
		//거꾸로 만들기
		for(int i = 10; i > 0; i--) {
			for(int j = 0; j < i ; j++) {
				System.out.print("*");
			}
			System.out.println();
		}

		
	}
}
