
public class ForLoopTest03 {

	public static void main(String[] args) {
		
		int randomValue = 0;
		int sum = 0;
		
		while(true) {
			randomValue = (int)(Math.random() * 150) + 1;
			
			if (randomValue % 2 != 0) {
				continue;
			}else if(randomValue == 100) {
				break;
			}
			
			sum += randomValue;
		}
		
		System.out.println("합 : " + sum);
		
	}
}
