
public class StudentMain {

	public static void main(String[] args) {
		
		//학생 클래스 선언
		/**
		 * 클래스명 지시자 = new 생성자();
		 */
		Student st = new Student();
		
		st.setName("홍길동");
		st.setAge(100);
		st.setGender("남자");
		st.setKor(90);
		st.setEng(10);
		st.setMath(100);
		
		
		//데이터 출력
		System.out.println("이름 : " + st.getName() + "  나이 : " + st.getAge() 
							+"살    총점 : " + st.getTotal() + "점    평균 : " + st.getAvg() + "점");


	}

}
