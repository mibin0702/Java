import java.math.BigDecimal;
import java.math.RoundingMode;

public class Student {
	
	private String name;
	private String gender;
	private int age;
	private int kor;
	private int eng;
	private int math;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	
	
	public int getTotal() {
		return ( this.getKor() + this.getEng() + this.getMath());
	}
	
	public double getAvg() {
		return new BigDecimal( (double)getTotal() / 3).setScale(2, RoundingMode.HALF_UP).doubleValue();
	} 
	// java에서 소수점을 비교적 정확하게 구할수 있는 건 BigDecimal을 사용하는 것이다
	// RoundingMode.HALF_UP는 Static변수로 되어있어 클래스의 선언없이 사용이 가능하다.

}
