import java.util.Arrays;
import java.util.Scanner;

/**
 * 로또 만들기
 * @author PC
 *
 */
public class LottoTest {

	public static void main(String[] args) {
		
		// 사용자 로또
		int[] user = new int[6];
		// 컴퓨터 로또
		int[] com = new int [6];
		// 보너스번호
		int bonusNum = 0;
		// 임시변수
		int tempVal = 0;
		// 논리형 변수 boolean.
		boolean	isExist = false;
		// 입력을 받기위한 scanner;
		Scanner scan = new Scanner(System.in);
		
		int loopCount = 0;
		
		
		//컴퓨터 로또를 만들자...이유는...모르면 못맞추기 때문에
		while(loopCount <= 6) {
			
			tempVal = (int)(Math.random() * 45) +1;
			//처음 시작을 비교할 필요가 없어요.
			if(loopCount == 0) {
				com[loopCount++] = tempVal;
			}else {
				//중복검사
				for(int i = 0; i < loopCount; i++) { //이미 들어있는 값끼리만 비교하기 때문에 loopCount보다 적은 범위로 설정
					if(com[i] == tempVal) {
						isExist = true;
						break;
					}
				} //end 중복검사
				
				if(!isExist) {
					
					if(loopCount == 6) {
						bonusNum = tempVal;
						break; // while문 종료
					} else {
						com[loopCount++] = tempVal;
					}
				}else {
					//다음 검사를 위해 초기화
					isExist = false;
				}
			}
		} // com while 종료
		
		//컴퓨터 로또 확인
		Arrays.sort(com);
		System.out.println(Arrays.toString(com) + ", " + bonusNum);
		
		//사용자 로또 만들기
		loopCount = 0; // 재활용을 위한 초기화
		while(loopCount < 6) {
			System.out.println("(1 ~ 45) 숫자를 입력 : ");
			tempVal = scan.nextInt(); // 숫자형 키보드 값 입력받기
			//유효 숫자값 판별
			if (tempVal <= 0 || tempVal > 45) {
				System.out.println("1 ~ 45사이 숫자만 입력가능");
				continue;
			}
			//처음이면 그냥 넣자.
			if(loopCount == 0) {
				user[loopCount++] = tempVal;
			}else {
				//중복검사
				for(int i = 0; i < loopCount; i++) { //이미 들어있는 값끼리만 비교하기 때문에 loopCount보다 적은 범위로 설정
					if(user[i] == tempVal) {
						isExist = true;
						break;
					}
				} //end 중복검사
				
				if(!isExist) {
					user[loopCount++] = tempVal;
				}else {
					//다음검사를 위해 초기화
					isExist = false;
				}
			}
		}// user while 종료
		
		Arrays.sort(user); //오름차순 정렬
		System.out.println(Arrays.toString(user));
		
		// 두 배열의 비교!!
		int isCorrect = 0; // 맞은 개수
		int bonusCount = 0; // 보너스 숫자
		for(int i = 0; i < user.length; i++) {
			for(int j = 0; j < com.length; j++) {
				
				if(bonusCount == 0) {
					if(user[i] == bonusNum) {
						bonusCount++;
					}
				}
				if(user[i] == com[j]) {
					isCorrect++;
					//보너스 번호 찾기 전에는 loop가 다 돌아야한다.
					if(bonusCount > 0) {
						break;
					}
				}
			}
		} // 비교 loop 종료
		
		//비교결과를 이용한 등수 출력
		if(isCorrect == 6) {
			System.out.println("1등 축하합니다.");
		}else if( isCorrect == 5 && bonusCount == 1) {
			System.out.println("2등 축하합니다.");
		}else if( isCorrect == 5 && bonusCount == 0) {
			System.out.println("3등 아깝네요.");
		}else if( isCorrect == 4) {
			System.out.println("4등 더 좋은 기회가 올겁니다.");
		}else if( isCorrect == 3) {
			System.out.println("5등 한번더 도전하세요.");
		}else {
			System.out.println("아쉽네요 다음번에 도전하세요");
		}
	
		//jdk 1.7부터 닫아줘야 함
		scan.close();
	}

}
