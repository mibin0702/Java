import java.util.Scanner;

public class WhileTest01 {

	public static void main(String[] args) {
		
		/**
		 * 키보드 입력을 받기 위한...Scanner.
		 */
		Scanner scan = new Scanner(System.in);
		int correctNum = 0; //업& 다운 정답값
		int userInput = 0; // 사용자 입력 값.
		
		int count = 0; // 실행횟수.
		
		correctNum = (int)(Math.random() * 50) + 1; //1~50까지의 숫지 중에서 정답을 랜덤으로
		while(true) {
			
			System.out.println("숫자를 맞춰보세요? :");
			userInput = scan.nextInt();
			
			if(count < 10) { //실행횟수가 10회 이하라면
				if(userInput == correctNum) { // 입력값과 정답이 같을 때
					System.out.println("정답입니다!");
					break; //답을 맞췄으니 더 이상 진행되지 않도록 강제종료
				}else if(userInput > correctNum) {
					System.out.println("down!");
					count++; // 틀렸으니 실행횟수 추가
				}else {
					System.out.println("up!");
					count++;
				}
			}else { //실행횟수가 10회 초과한 경우
				System.out.println("패했습니다. 정답은 : " + correctNum);
				break;
			}
			
		}

		
		
	}
}
