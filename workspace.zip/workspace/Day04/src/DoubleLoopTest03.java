
public class DoubleLoopTest03 {

	public static void main(String[] args) {

		for(int i = 0; i < 10; i ++) {
			/*공백찍기 위한 for 문*/
			for(int j = (10-i); j > 0; j--) {
				System.out.print(" ");
			}
			
			/*실제 별을 찍기 위한 for 문*/
			for(int k = 0; k <(2*i)+1; k++) {
				System.out.print("*");
			}
			
			/*라인 변경을 위해서*/
			System.out.println();
		}
		
		
	}
}
