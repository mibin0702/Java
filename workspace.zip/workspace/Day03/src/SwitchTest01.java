
public class SwitchTest01 {

	public static void main(String[] args) {
		
		int num = 0;
		
		// 1 ~ 100까지 최저 50부터.
		num = 50 + (int)(Math.random() * 50) +1;
		
		/**
		 * switch(조건대상) {....
		 */
		switch((num / 10)) {
		case 10:
			System.out.println("만점!");
			break;
		case 9:
			System.out.println("A");
			break;
		case 8:
			System.out.println("B");
			break;
		case 7:
			System.out.println("C");
			break;
		default:
			System.out.println("F");
		}
		/**
		 * 조건대상을 잘줘야 범위조건을 준 것처럼 할 수 있다
		 * case의 조건은 비교단일조건이므로 단순해야한다.
		 * 간단한 명령에 의한 기능의 분기를 태울 때 좋다.(가독성)
		 * 실행문이 3문장이상으로 길어질 경우 함수로 뺀다.
		 */

	}
}
