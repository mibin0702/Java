
public class IfTest01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/**
		 * 랜덤함수
		 * 범위내에 값을 랜덤하게 출력해주는 기능.
		 */
		int random = 0;
		
		//1~100사이의 숫자 중 랜덤하게 출력됨.
		random = 60 +( (int)(Math.random() * 40) +1 ); //Math.random()는 Math라는 클래스 안에 있는 random이라는 함수를 사용한다는 의미!
		
		if ( random == 100 ) {
			System.out.println("만점!");
		}else if (random >=90 && random < 100) { //조건식 작성시 범위가 겹치지 않도록 주의!
			System.out.println("점수는 A");
		}else if (random >=80 && random < 90) {
			System.out.println("점수는 B");
		}else if (random >=70 && random < 80) {
			System.out.println("점수는 C");
		}else {
			System.out.println("점수는 F");
		}

	}

}
