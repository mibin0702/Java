import java.util.Arrays;

/**
 * 배열에서 최대/최소값을 찾기
 * @author Administrator
 *
 */
public class ArrayTest04 {

	public static void main(String[] args) {
		
		int min = Integer.MAX_VALUE; //최소값 변수
		int max = Integer.MIN_VALUE; //최대값 변수
		//int의 클래스형 Integer에서 min에 max를 max에 min을 넣은 것은 어떤 값이라도 넣어서 비교하기 위해서
		
		int[] array = new int[10];
		
		//배열에 값을 입력하기
		for(int i = 0; i < array.length; i++) {
			array[i] = (int)(Math.random() * 50) + 1;
		}
		
		//최대값/ 최소값 찾기
		for(int i = 0; i < array.length; i++) {
			
			//max 보다 크면 변경
			if(max < array[i]) {
				max = array[i];
			}
			
			//min 보다 작으면 변경
			if(min > array[i]) {
				min = array[i];
			}
		}
		
		System.out.println(Arrays.toString(array));
		System.out.println("최대값 : " + max + ", 최소값 : " + min);

	}

}
