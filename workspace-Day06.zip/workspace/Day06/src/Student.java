import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 학생정보를 담는 클래스
 * @author Administrator
 *
 */
public class Student {
	
	/**학생정보를
	 * 담는 변수들...
	 * member 변수 또는 인스턴스 변수라고 함.
	 */
	private String name;	// 이름
	private String gender;	// 성별
	private int age;		// 나이
	private String grade;	// 학년
	private int kor;		// 국어점수
	private int eng;		// 영어점수
	private int math;		// 수학점수
	
	
	/**
	 * getter / setter
	 * getter setter 만드는 법
	 * => tool 사용 : 메뉴에 Source->
	 * @param name
	 */
	public void setName(String name) {
		this.name = name; // this는 Class에 있는 이름이라는 것을 알려주기 위한 것이다.
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	/* 학생 성적의 총점을 구하는 메서드  */
	public int getTotal() {
	//	return (this.kor + this.math + this.eng);
		return (this.getKor() + this.getMath() + this.getEng());
		
		//둘 다 가능하다. 첫번째는 변수에 직접접근, 두번째는 getter를 이용해서 간접접근
		//getter와 setter가 내부의 의미부여상 두번째가 맞다.
	}
	
	/* 학생성적의 평균을 구하는 메서드 */
	public double getAvg() {
		
		double avg = new BigDecimal( (double)getTotal() / 3 ).setScale(2, RoundingMode.HALF_UP).doubleValue(); //BigDecimal에 임의로 결과 저장,점수를 소수점 2자리까지 반올림으로 처리, double타입으로 출력
		// double jumsu = (double)getTotal() / 3;
		// double avg = new BigDecimal( jumsu ).setScale(2, RoundingMode.HALF_UP).doubleValue();
		
		return avg;
	}
	
	
	
	
	
}
