import java.util.Arrays;

/**
 * 중복값 넣지 않는 예제
 * @author Administrator
 *
 */
public class ArrayTest05 {

	public static void main(String[] args) {
		
		int[] array = new int[10];
		int tempVal = 0; //임시 변수
		
		for(int i = 0; i < array.length; i++) {
			
			tempVal = (int)(Math.random() * 30) +1;
			
			array[i] = tempVal; 
			
			/**
			 * 중복 비교 loop
			 * 중복된 값이 있으면 i 값을 하나 빼고...
			 * loop를 중지한다.
			 */
			for(int j = 0; j < i; j ++) {
				if(tempVal == array[j]) {
					System.out.println("중복" + i);
					i--;
					break;
				}
			}
		}
		
		System.out.println(Arrays.toString(array));

	}

}
