
public class ArrayTeat01 {

	public static void main(String[] args) {
		
		// 배열 선언1
		int[] array = new int[4]; //4개의 공간을 가지는 배열 선언.
		
		/** 배열 선언2
		 * 배열의 값을 바로 부여하는 것은
		 * 배열을 선언할때만 가능하다.
		 * 선언 후에는 불가!
		 */
		int[] array2 = { 1, 2, 3, 4, 5};
		
		int sum = 0; // 합
		
		for(int i = 0; i < array2.length ; i++ ) { // for에서 숫자를 고정하는 하드코딩은 지양하고 대신 length를 사용한다. 
			sum += array2[i];
		}
		System.out.println(" 합 : " + sum );
		
		// 일반형 배열변수는 초기화가 필요없지만 객체형 배열에는 초기화가 필요하다.
		// 객체형 배열에는 공간에 null이 들어가기 때문에 (null은 없다라는 의미->0과는 다르다 0은 0이라는 자연수가 있다는 의미)
		//=> 일반형과 참조형 배열의 차이
		// 캐릭터형은 아스키코드 값으로 들어가 있다.
		
		
	}

}
