
public class StarTest01 {

	public static void main(String[] args) {
		
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j <= (10+i) ; j++) { // 10+i는 j가 반복되는 횟수 -> 한줄에 공백과 별은 모두 몇개인지 생각
				
				if(j < (10-i)) { //공백이 반복되면서 10개에서 점점 줄어드므로 10-i는 공백의 갯수
					System.out.print(" ");
				}else { // j의 길이에서 공백을 뺀만큼 *을 출력
					System.out.print("*");
				}
				
			}
			System.out.println(); // j가 한번 돈 후에 다음줄에 출력되도록 줄바꿈출력
		}
		
	}
}
