import java.util.Arrays;

public class ArrayTest02 {

	public static void main(String[] args) {
		
		int[] array = new int[5];
		
		//배열에 값을 입력하기
		for(int i = 0; i < array.length; i++) {
			array[i] = (int)(Math.random() * 30) + 1;
		}
		
		//출력 - 배열의 유틸 class 를 이용하여 출력(단순출력의 경우)
		System.out.println(Arrays.toString(array)); // Arrays라는 함수 중 toString을 사용하면 배열을 string타입으로 출력
		
		//버블 정렬을 이용한 sorting
		
		//임시변수..
		int tempVal = 0;
		
		for(int i = array.length-1; i>0 ; i--) { //j의 값이 하나씩 줄어들기 때문에
			for(int j = 0; j < i; j++) { // j의 값을 i의 값으로, j<i는 j의 값이 더 크면 오류가 발생
				if(array[j] > array[j+1]) { //앞과 뒤의 숫자를 비교
					tempVal = array[j+1]; 
					array[j+1] = array[j]; //앞과 뒤를 비교해서 바꾸는 공식
					array[j] = tempVal;
				}
			}
		}
		
		System.out.println(Arrays.toString(array));
	}

}
